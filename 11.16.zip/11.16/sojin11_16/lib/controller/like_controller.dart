import 'package:get/get.dart';
import 'package:sojin11_16/model/item.dart';

class LikeController extends GetxController {
  RxList<Item> likeItems = <Item>[].obs;

  void clickLike(Item item) {
    if (likeItems.contains(item)) {
      likeItems.remove(item);
    } else {
      likeItems.add(item);
    }
  }

  static LikeController get to => Get.find();
  // final LikeController likeController = Get.find<LikeController>();
  //이 코드 항상 안 써도 됨
}
