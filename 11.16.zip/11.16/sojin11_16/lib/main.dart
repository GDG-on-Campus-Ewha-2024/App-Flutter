import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sojin11_16/controller/like_controller.dart';
import 'package:sojin11_16/controller/navigator_controller.dart';
import 'package:sojin11_16/presentation/screen/s_home.dart';
import 'package:sojin11_16/presentation/screen/s_main.dart';

void main() {
  Get.put(LikeController());
  Get.put(NavigatorController()); //컨트롤러 등록
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'sojin11_16',
      theme: ThemeData(
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}
