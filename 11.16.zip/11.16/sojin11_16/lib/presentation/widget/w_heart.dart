import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sojin11_16/common/app_fonts.dart';
import 'package:sojin11_16/common/app_colors.dart';
import 'package:sojin11_16/model/item.dart';

import '../../controller/like_controller.dart';

class HeartWidget extends StatelessWidget {
  const HeartWidget({
    super.key,
    required this.likeController,
    required this.item,
    required this.borderColor,
  });

  final LikeController likeController;
  final Item item;
  final Color borderColor;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => likeController.clickLike(item),
      child: Obx(
        //getx 화면 바로바로 바뀔려면 obx로 묶기
        () => likeController.likeItems.contains(item)
            ? const Icon(
                Icons.favorite_sharp,
                color: AppColors.orange,
                size: 20,
              )
            : Icon(
                Icons.favorite_border,
                size: 20,
                color: borderColor,
              ),
      ),
    );
  }
}
