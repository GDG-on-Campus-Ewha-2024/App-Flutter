import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sojin11_16/common/app_fonts.dart';
import 'package:sojin11_16/common/app_colors.dart';
import 'package:sojin11_16/model/item.dart';
import 'package:sojin11_16/presentation/widget/w_heart.dart';

import '../../controller/like_controller.dart';

class itemWidget extends StatelessWidget {
  const itemWidget({
    super.key,
    required this.item,
  });
  final Item item;

  @override
  Widget build(BuildContext context) {
    final LikeController likeController = Get.find<LikeController>();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          children: [
            Image.asset('asset\image\icecream.jpg',
                width: 190, height: 200, fit: BoxFit.cover //비율무너져도 박스 꽉 채움
                ),
            Positioned(
              left: 0,
              bottom: 0,
              child: Container(
                  decoration:
                      BoxDecoration(color: AppColors.black.withOpacity(0.5)),
                  child: Text(
                    '직책 세일',
                    style: AppFonts.content.copyWith(color: AppColors.white),
                  )),
            ),
            Positioned(
              right: 0,
              left: 0,
              child: HeartWidget(
                likeController: likeController,
                item: item,
                borderColor: AppColors.white,
              ),
            )
          ],
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(
                        item.shopName,
                        style: AppFonts.title.copyWith(fontSize: 15),
                      ),
                      Container(
                        //자식이 생겨서 컨테이너의 크기 자동지정
                        margin: EdgeInsets.only(left: 5),
                        padding: EdgeInsets.all(3),
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.orange.withOpacity(0.3)),
                        child: Text(
                          'M',
                          style: AppFonts.content
                              .copyWith(color: AppColors.orange, fontSize: 10),
                        ),
                      ),
                    ],
                  ),
                  Icon(
                    Icons.more_vert,
                    size: 20,
                    color: AppColors.gray,
                  )
                ],
              ),
              Text(
                item.name,
                style: AppFonts.content,
              ),
              Row(
                children: [
                  item.isSale
                      ? Text(
                          '${item.sale}%',
                          style: AppFonts.title
                              .copyWith(color: AppColors.pink, fontSize: 16),
                        )
                      : const SizedBox(),
                  Text(item.price.toString(),
                      style: AppFonts.title.copyWith(
                        color: AppColors.black,
                        fontSize: 16,
                      )),
                  Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                      decoration: BoxDecoration(
                          color: AppColors.lightGray.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(3)),
                      child: Text(
                        '무료배송',
                        style: AppFonts.subText
                            .copyWith(fontSize: 13, color: AppColors.gray),
                      )),
                  Text(
                    '${item.people}만 명 보는 중',
                    style: AppFonts.subText
                        .copyWith(color: AppColors.lightGray, fontSize: 10),
                  )
                ],
              ),
            ],
          ),
        )
      ],
    );
  }
}
