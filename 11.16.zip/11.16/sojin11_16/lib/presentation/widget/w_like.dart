import 'package:sojin11_16/presentation/widget/w_heart.dart';
import 'package:sojin11_16/importex.dart';
import '../../controller/like_controller.dart';

class LikeWidget extends StatelessWidget {
  const LikeWidget({
    super.key,
    required this.item,
  });
  final Item item;

  @override
  Widget build(BuildContext context) {
    final LikeController likeController = Get.find<LikeController>();
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween, //하트랑 글자 간격 멀리
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          //글자들끼리 모음
          children: [
            Image.asset(
              'asset\image\pencil.jpg',
              width: 100,
              height: 100,
              fit: BoxFit.cover,
            ),
            const SizedBox(
              //이미지와 설명 사이에 박스
              width: 10,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start, //왼쪽정렬
              children: [
                Text(
                  item.name,
                  style: AppFonts.content.copyWith(fontSize: 18),
                ),
                Text(
                  item.location,
                  style: AppFonts.content
                      .copyWith(fontSize: 13, color: AppColors.gray),
                ),
                Text(
                  '${item.price}원',
                  style: AppFonts.title
                      .copyWith(fontSize: 18, color: AppColors.black),
                ),
              ],
            ),
          ],
        ),
        HeartWidget(
          likeController: likeController,
          item: item,
          borderColor: AppColors.gray,
        )
      ],
    );
  }
}
