import 'package:sojin11_16/importex.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Text(
      'chat',
      style: TextStyle(fontSize: 100),
    );
  }
}
