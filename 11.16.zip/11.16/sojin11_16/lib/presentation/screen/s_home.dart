import 'package:flutter/material.dart';
import 'package:sojin11_16/common/app_fonts.dart';
import 'package:sojin11_16/controller/navigator_controller.dart';
import 'package:sojin11_16/importex.dart';
import 'package:sojin11_16/presentation/widget/w_item.dart';
import 'package:sojin11_16/presentation/screen/s_like.dart';
import 'package:sojin11_16/model/item.dart';

final items = [
  Item(
      id: 1,
      shopName: 'shopName1',
      name: 'name1',
      sale: 10,
      isSale: true,
      people: 1.5,
      price: 12500,
      like: false,
      location: '이대역'),
  Item(
      id: 2,
      shopName: 'shopName2',
      name: 'name2',
      sale: 13,
      isSale: true,
      people: 1.5,
      price: 12000,
      like: false,
      location: '아현역'),
  Item(
      id: 3,
      shopName: 'shopName3',
      name: 'name3',
      sale: 0,
      isSale: false,
      people: 2,
      price: 20000,
      like: true,
      location: '신촌역'),
];

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 150 / 250,
            crossAxisSpacing: 10,
            mainAxisSpacing: 20),
        itemBuilder: (context, index) => itemWidget(item: items[index]),
        itemCount: items.length,
      ),
    );
  }
}
