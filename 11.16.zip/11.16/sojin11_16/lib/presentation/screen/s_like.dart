import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sojin11_16/common/app_fonts.dart';
import 'package:sojin11_16/common/app_colors.dart';
import 'package:sojin11_16/controller/like_controller.dart';
import 'package:sojin11_16/presentation/widget/w_like.dart';
import 'package:sojin11_16/presentation/screen/s_home.dart';

class LikeScreen extends StatelessWidget {
  const LikeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          //automaticallyImplyLeading: false, //자동으로 만들어진 뒤로가기 버튼 없애기
          title: Text(
            '관심목록',
            style: AppFonts.title,
          ),
        ),
        body: ListView.separated(
          // separatorBuilder: ((context, index) => const SizedBox(
          //       height: 10, //상품사이 간격을 박스로
          //     )),
          // padding: EdgeInsets.symmetric(          horizontal: 12,
          // ),
          padding: const EdgeInsets.symmetric(horizontal: 20),
          separatorBuilder: ((context, index) => Container(
                margin: const EdgeInsetsDirectional.symmetric(vertical: 10),
                height: 1,
                width: double.infinity,
                color: AppColors.lightGray,
              )),
          itemBuilder: (context, index) => LikeWidget(
            item: LikeController.to.likeItems[index],
          ),
          itemCount: LikeController.to.likeItems.length,
        ));
  }
}
