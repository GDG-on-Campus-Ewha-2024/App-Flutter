import 'package:sojin11_16/controller/navigator_controller.dart';
import 'package:sojin11_16/importex.dart';
import 'package:sojin11_16/presentation/screen/s_chat.dart';
import 'package:sojin11_16/presentation/screen/s_home.dart';
import 'package:sojin11_16/presentation/screen/s_like.dart';
import 'package:sojin11_16/presentation/screen/s_people.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "대신동",
          style: AppFonts.title,
        ),
        actions: [
          const Icon(Icons.search, size: 25),
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 10), //좌우간격 symmetric
            child: GestureDetector(
                onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => LikeScreen())),
                child: Icon(
                  Icons.favorite_outline,
                  size: 25,
                )),
          )
        ],
        centerTitle: false,
      ),
      body: Obx(() {
        // switch (NavigatorController.to.currentIndex.value) {
        //   case 0:
        //     return const HomeScreen();
        //   case 1:
        //     return PeopleScreen();
        //   case 2:
        //     return ChatScreen();
        //   default:
        //     return const SizedBox();
        // }
        return IndexedStack(
          index: NavigatorController.to.currentIndex.value,
          children: const [HomeScreen(), PeopleScreen(), ChatScreen()],
        );
      }),
      bottomNavigationBar: Obx(() => BottomNavigationBar(
              currentIndex: NavigatorController.to.currentIndex.value,
              onTap: (index) => NavigatorController.to.tapIndex(index),
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home), label: 'home'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.people), label: 'people'),
                BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'chat')
              ])),
    );
  }
}
