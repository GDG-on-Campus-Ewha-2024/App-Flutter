import 'package:sojin11_16/importex.dart';

class PeopleScreen extends StatelessWidget {
  const PeopleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Text(
      'people',
      style: TextStyle(fontSize: 100),
    );
  }
}
