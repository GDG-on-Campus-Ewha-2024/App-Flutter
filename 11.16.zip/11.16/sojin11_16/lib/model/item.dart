class Item {
  final int id; //유니크. 데이터베이스에서 식별용

  final String shopName;
  final String name;
  final int sale;
  final bool isSale;
  final double people;
  final int price;
  final bool like;
  final String location;

  Item(
      {required this.id,
      required this.shopName,
      required this.name,
      required this.sale,
      required this.isSale,
      required this.people,
      required this.price,
      required this.like,
      required this.location});
}
