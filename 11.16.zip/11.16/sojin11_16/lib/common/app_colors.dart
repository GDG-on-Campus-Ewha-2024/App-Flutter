import 'dart:ui';
import 'package:flutter/material.dart';

class AppColors {
  static const orange = Color(0xffff6e5d);
  static const pink = Color(0xffFA6EE2);
  static const lightGray = Color(0xffB8BEC1);
  static const gray = Color(0xff687174);
  static const white = Color(0xffffffff);
  static const black = Color(0x00000000);
}
