import 'package:flutter/material.dart';
import 'package:sojin11_16/common/app_colors.dart';

class AppFonts {
  static const title = TextStyle(
    fontFamily: 'PretendardBold',
    color: AppColors.black,
    fontSize: 20,
  );
  static const subText = TextStyle(
    fontFamily: 'PretendardLight',
    color: AppColors.black,
    fontSize: 20,
  );
  static const content = TextStyle(
    fontFamily: 'PretendardRegular',
    color: AppColors.black,
    fontSize: 20,
  );
}
