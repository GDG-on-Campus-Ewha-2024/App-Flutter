package com.example.sojin11_16

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
